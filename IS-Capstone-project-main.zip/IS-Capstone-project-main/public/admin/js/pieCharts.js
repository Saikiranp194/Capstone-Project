
// Fetching data from each endpoint and creating the chart
async function fetchDataAndRenderChart() {
    try {
        // Fetch data from the backend
        const wasteData = await fetch('/admin/api/waste-by-type').then(res => res.json());
        const landfillData = await fetch('/admin/api/landfill').then(res => res.json());
        const foodWasteData = await fetch('/admin/api/food-waste').then(res => res.json());

        console.log(wasteData)
        console.log(landfillData)
        console.log(foodWasteData)

        // Data for the chart
        const data = {
            labels: [
                'Aluminum', 'Cardboard', 'Glass', 'Metal Cans', 'Metal Scrap', 
                'Books', 'Mixed Paper', 'Newspaper', 'White Paper', 
                'Plastic PET', 'HDPE Colored', 'HDPE Natural', 'Landfill', 'Food Waste Compost'
            ],
            datasets: [{
                label: 'Waste Composition',
                data: [
                    wasteData.aluminum,
                    wasteData.cardboard,
                    wasteData.glass,
                    wasteData.cans,
                    wasteData.scrap,
                    wasteData.books,
                    wasteData.mixedPaper,
                    wasteData.newspaper,
                    wasteData.whitePaper,
                    wasteData.PET,
                    wasteData.HDPEColored,
                    wasteData.HDPENatural,
                    landfillData.totalWeight,
                    foodWasteData.totalFoodWaste
                ],
                backgroundColor: [
                    '#FF6384', '#FF6384', '#FF6384', '#FF6384', '#FF6384',
                    '#FF6384', '#FF6384', '#FF6384', '#FF6384', 
                    '#FF6384', '#FF6384', '#FF6384', '#E7E9ED', '#36A2EB'
                ],
                hoverBackgroundColor: [
                    '#FFCE56', '#FFCE56', '#FFCE56', '#FFCE56', '#FFCE56',
                    '#FFCE56', '#FFCE56', '#FFCE56', '#FFCE56',
                    '#FFCE56', '#FFCE56', '#FFCE56', '#FFCE56', '#FFCE56'
                ]
            }]
        };

        // Render the pie chart
        const ctx = document.getElementById('myPieChart').getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: data
        });
    } catch (error) {
        console.error('Error fetching data or rendering chart:', error);
    }
}

// Run the function on page load
fetchDataAndRenderChart();
