document.addEventListener('DOMContentLoaded', () => {
    const usersTableBody = document.querySelector('#users-table tbody');
    const adminsTableBody = document.querySelector('#admins-table tbody');
    const modal = document.getElementById('user-modal');
    const modalTitle = document.getElementById('modal-title');
    const closeModal = document.querySelector('.close');
    const addUserBtn = document.getElementById('add-user-btn');
    const saveUserBtn = document.getElementById('save-user-btn');
    const userForm = document.getElementById('user-form');
    let editingUserId = null;
    let editingAdminId = null;

    function fetchUsers() {
        fetch('/admin/api/getUsers')
            .then(res => res.json())
            .then(data => { 
                if(data.success){
                    populateUsersTable(data.users)
                }
            })
            .catch(err => console.error(err));
    }

    function fetchAdmins() {
        fetch('/admin/api/getAdmins')
            .then(res => res.json())
            .then(data => { 
                if(data.success){
                    populateAdminsTable(data.users)
                }
            })
            .catch(err => console.error(err));
    }

    function populateUsersTable(users) {
        usersTableBody.innerHTML = '';
        if(users.length > 0){
            users.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${user.username}</td>
                    <td>${user.email}</td>
                    <td>
                        <button class="edit" onclick="editUser('${user._id}', '${user.username}', '${user.email}')">Edit</button>
                        <button class="delete" onclick="deleteUser('${user._id}')">Delete</button>
                    </td>
                `;
                usersTableBody.appendChild(row);
            });
        }
        
    }
    function populateAdminsTable(users) {
        adminsTableBody.innerHTML = '';
        if(users.length > 0){
            users.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${user.username}</td>
                    <td>${user.email}</td>
                    <td>
                        <button class="edit" onclick="editAdmin('${user._id}', '${user.username}', '${user.email}')">Edit</button>
                        <button class="delete" onclick="deleteAdmin('${user._id}')">Delete</button>
                    </td>
                `;
                adminsTableBody.appendChild(row);
            });
        }
        
    }

    // Add new user
    addUserBtn.addEventListener('click', () => {
        modalTitle.textContent = 'Add User';
        userForm.reset();
        modal.style.display = 'block';
    });

    // Close modal
    closeModal.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    };

    // Save user (add/edit)
    userForm.addEventListener('submit', e => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const userId = document.getElementById('user-id').value;

        if (editingUserId) {
            fetch(`/admin/api/editUser/${editingUserId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, email })
            })
                .then(res => res.json())
                .then(() => {
                    fetchUsers();
                    modal.style.display = 'none';
                })
                .catch(err => console.error(err));
        }
        else if(editingAdminId){
            fetch(`/admin/api/editAdmin/${editingAdminId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, email })
            })
                .then(res => res.json())
                .then(() => {
                    fetchAdmins();
                    modal.style.display = 'none';
                })
                .catch(err => console.error(err));
        } else {
            fetch('/admin/api/addUser', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, email })
            })
                .then(res => res.json())
                .then(() => {
                    fetchUsers();
                    modal.style.display = 'none';
                })
                .catch(err => console.error(err));
        }
    });

    // Edit user
    window.editUser = function(id, name, email) {
        editingUserId = id;
        document.getElementById('username').value = name;
        document.getElementById('email').value = email;
        modalTitle.textContent = 'Edit User';
        modal.style.display = 'block';
    };

    // Delete user
    window.deleteUser = function(id) {
        if (confirm('Are you sure you want to delete this user?')) {
            fetch(`/admin/api/deleteUser/${id}`, {
                method: 'DELETE'
            })
                .then(res => res.json())
                .then(() => fetchUsers())
                .catch(err => console.error(err));
        }
    };

    // Edit user
    window.editAdmin = function(id, name, email) {
        editingAdminId = id;
        document.getElementById('username').value = name;
        document.getElementById('email').value = email;
        modalTitle.textContent = 'Edit Admin';
        modal.style.display = 'block';
    };

    // Delete user
    window.deleteAdmin = function(id) {
        if (confirm('Are you sure you want to delete the admin?')) {
            fetch(`/admin/api/deleteAdmin/${id}`, {
                method: 'DELETE'
            })
                .then(res => res.json())
                .then(() =>{
                    fetchAdmins();
                    if(sessionStorage.getItem('id') == id){
                        sessionStorage.clear()
                        window.location.reload()
                    }
                })
                .catch(err => console.error(err));
        }
    };

    fetchUsers();
    fetchAdmins();
});
