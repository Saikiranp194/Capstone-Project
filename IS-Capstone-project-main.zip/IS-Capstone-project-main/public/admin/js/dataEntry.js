const baseURL = '/admin/api'; 

// Function to switch tabs
function openTab(event, tabName, tableName) {
    // Hide all tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        content.classList.remove('active');
    });
    const tableContents = document.querySelectorAll('.table-content');
    tableContents.forEach(content => {
        content.classList.remove('active');
    });
 
    // Remove active class from all tab buttons
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.classList.remove('active');
    });

    // Show the current tab and add active class to the clicked button
    document.getElementById(tabName).classList.add('active');
    document.getElementById(tableName).classList.add('active');
    event.currentTarget.classList.add('active');
}

const hiddenType = document.getElementById('hidden-type')
const hiddenId = document.getElementById('hidden-id')

async function fetchData() {
    try {
        const collectionResponse = await fetch(`${baseURL}/recycle-collection`);
        const revenueResponse = await fetch(`${baseURL}/recycle-revenue`);
        const landfillResponse = await fetch(`${baseURL}/landfill-expense`);

        const collections = await collectionResponse.json();
        const revenues = await revenueResponse.json();
        const landfills = await landfillResponse.json();

        populateCollectionTable(collections);
        populateRevenueTable(revenues);
        populateLandfillTable(landfills);
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

// Function to populate revenue table
function populateRevenueTable(data) {
    const tbody = document.getElementById('revenue-list');
    tbody.innerHTML = ''; // Clear existing rows

    data.forEach(entry => {
        const row = document.createElement('tr');

        // Format the saleDate
        const saleDate = new Date(entry.saleDate).toLocaleDateString();

        // Get materialType values, including nested objects
        const aluminum = entry.materialType.aluminum;
        const cardboard = entry.materialType.cardboard;
        const glass = entry.materialType.glass;
        const metalCans = entry.materialType.metal.cans;
        const metalScrap = entry.materialType.metal.scrap;
        const paperBooks = entry.materialType.paper.books;
        const paperMixed = entry.materialType.paper.mixed;
        const paperNewspaper = entry.materialType.paper.newspaper;
        const paperWhite = entry.materialType.paper.white;
        const plasticPET = entry.materialType.plastic.PET;
        const plasticHDPEColored = entry.materialType.plastic.HDPEColored;
        const plasticHDPENatural = entry.materialType.plastic.HDPENatural;

        // Construct table row with material type values
        row.innerHTML = `
            <td>${saleDate}</td>
            <td>${aluminum}</td>
            <td>${cardboard}</td>
            <td>${glass}</td>
            <td>${metalCans}</td>
            <td>${metalScrap}</td>
            <td>${paperBooks}</td>
            <td>${paperMixed}</td>
            <td>${paperNewspaper}</td>
            <td>${paperWhite}</td>
            <td>${plasticPET}</td>
            <td>${plasticHDPEColored}</td>
            <td>${plasticHDPENatural}</td>
            <td>${entry.buyer}</td>
        `;

        // Create edit button
        const editButton = document.createElement('button');
        editButton.innerText = 'Edit';
        editButton.className = 'edit';
        editButton.onclick = () => openEditModal('recycle-revenue', entry._id, entry);


        // Create delete button
        const deleteButton = document.createElement('button');
        deleteButton.innerText = 'Delete';
        deleteButton.className = 'delete';
        deleteButton.onclick = () => deleteItem('recycle-revenue', entry._id);

        // Append buttons to the row
        const actionCell = document.createElement('td');
        actionCell.appendChild(editButton);
        actionCell.appendChild(deleteButton);
        row.appendChild(actionCell);

        // Append the row to the table body
        tbody.appendChild(row);
    });
}

// Function to populate the table with landfill data
function populateLandfillTable(data) {
    const tbody = document.getElementById('landfill-list');
    tbody.innerHTML = ''; 
    data.forEach(entry => {

       // console.log( entry._id)
        const row = document.createElement('tr');
        let date = new Date(entry.landfillDate).toLocaleDateString();

        row.innerHTML = `
            <td>${date}</td>
            <td>${entry.weight}</td>
            <td>${entry.expense}</td>
            <td>${entry.landfillHauler}</td>
        `;
        // Create edit button
        const editButton = document.createElement('button');
        editButton.innerText = 'Edit';
        editButton.className = 'edit';
        editButton.onclick = () => openEditModal('landfill-expense', entry._id, entry);


        // Create delete button
        const deleteButton = document.createElement('button');
        deleteButton.innerText = 'Delete';
        deleteButton.className = 'delete';
        deleteButton.onclick = () => deleteItem('landfill-expense', entry._id); 

        row.appendChild(editButton);
        row.appendChild(deleteButton);
        tbody.appendChild(row);
    });
}


// Function to populate collection table
function populateCollectionTable(data) {
    const tbody = document.getElementById('collection-list');
    tbody.innerHTML = '';

    data.forEach(entry => {
        const row = document.createElement('tr');
        const date = new Date(entry.date).toLocaleDateString();

        const foodWaste = entry.foodWaste;
        const aluminum = entry.aluminum;
        const cardboard = entry.cardboard;
        const glass = entry.glass;
        const metalCans = entry.metal.cans;
        const metalScrap = entry.metal.scrap;
        const paperBooks = entry.paper.books;
        const paperMixed = entry.paper.mixed;
        const paperNewspaper = entry.paper.newspaper;
        const paperWhite = entry.paper.white;
        const plasticPET = entry.plastic.PET;
        const plasticHDPEColored = entry.plastic.HDPEColored;
        const plasticHDPENatural = entry.plastic.HDPENatural;

        row.innerHTML = `
            <td>${date}</td>
            <td>${foodWaste}</td>
            <td>${aluminum}</td>
            <td>${cardboard}</td>
            <td>${glass}</td>
            <td>${metalCans}</td>
            <td>${metalScrap}</td>
            <td>${paperBooks}</td>
            <td>${paperMixed}</td>
            <td>${paperNewspaper}</td>
            <td>${paperWhite}</td>
            <td>${plasticPET}</td>
            <td>${plasticHDPEColored}</td>
            <td>${plasticHDPENatural}</td>
        `;

        // Create edit button
        const editButton = document.createElement('button');
        editButton.innerText = 'Edit';
        editButton.className = 'edit';
        editButton.onclick = () => openEditModal('recycle-collection', entry._id, entry);


        // Create delete button
        const deleteButton = document.createElement('button');
        deleteButton.innerText = 'Delete';
        deleteButton.className = 'delete';
        deleteButton.onclick = () => deleteItem('recycle-collection', entry._id);

        // Append buttons to the row
        const actionCell = document.createElement('td');
        actionCell.appendChild(editButton);
        actionCell.appendChild(deleteButton);
        row.appendChild(actionCell);

        // Append the row to the table body
        tbody.appendChild(row);
    });
}


async function addData(type, data) {
    try {
        const response = await fetch(`${baseURL}/${type}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
        if (response.ok) {
            await fetchData();
        }
    } catch (error) {
        console.error('Error adding data:', error);
    }
}

// Function to edit data
async function editItem(type, id) {
    const data = prompt(`Enter new data for ${type} (ID: ${id}):`);
    if (data) {
        try {
            const response = await fetch(`${baseURL}/${type}/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ data }), // Adjust as necessary based on your API structure
            });
            if (response.ok) {
                await fetchData(); // Refresh data after editing
            }
        } catch (error) {
            console.error('Error editing data:', error);
        }
    }
}

// Function to delete data
async function deleteItem(type, id) {
    if (confirm(`Are you sure you want to delete this ${type} (ID: ${id})?`)) {
        try {
            const response = await fetch(`${baseURL}/${type}/${id}`, {
                method: 'DELETE',
            });
            if (response.ok) {
                await fetchData();
            }
        } catch (error) {
            console.error('Error deleting data:', error);
        }
    }
}

// Event listeners for forms
document.getElementById('collection-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = {
        date: new Date(document.getElementById('collection-date').value), // Ensure it's a Date object
        foodWaste: parseFloat(document.getElementById('food-waste').value) || 0, // Convert to number and default to 0
        aluminum: parseFloat(document.getElementById('aluminum').value) || 0,
        cardboard: parseFloat(document.getElementById('cardboard').value) || 0,
        glass: parseFloat(document.getElementById('glass').value) || 0,
        metal: {
            cans: parseFloat(document.getElementById('metal-cans').value) || 0,
            scrap: parseFloat(document.getElementById('metal-scrap').value) || 0
        },
        paper: {
            books: parseFloat(document.getElementById('paper-books').value) || 0,
            mixed: parseFloat(document.getElementById('paper-mixed').value) || 0,
            newspaper: parseFloat(document.getElementById('paper-newspaper').value) || 0,
            white: parseFloat(document.getElementById('paper-white').value) || 0
        },
        plastic: {
            PET: parseFloat(document.getElementById('plastic-pet').value) || 0,
            HDPEColored: parseFloat(document.getElementById('plastic-hdpe-colored').value) || 0,
            HDPENatural: parseFloat(document.getElementById('plastic-hdpe-natural').value) || 0
        }
    };
    
    await addData('recycle-collection', data);
    document.getElementById('collection-form').reset();
});

document.getElementById('revenue-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = {
        saleDate: new Date(document.getElementById('revenue-date').value), // Ensure it's a Date object
        materialType: {
            aluminum: parseFloat(document.getElementById('revenue-aluminum').value) || 0,
            cardboard: parseFloat(document.getElementById('revenue-cardboard').value) || 0,
            glass: parseFloat(document.getElementById('revenue-glass').value) || 0,
            metal: {
                cans: parseFloat(document.getElementById('revenue-metal-cans').value) || 0,
                scrap: parseFloat(document.getElementById('revenue-metal-scrap').value) || 0,
            },
            paper: {
                books: parseFloat(document.getElementById('revenue-paper-books').value) || 0,
                mixed: parseFloat(document.getElementById('revenue-paper-mixed').value) || 0,
                newspaper: parseFloat(document.getElementById('revenue-paper-newspaper').value) || 0,
                white: parseFloat(document.getElementById('revenue-paper-white').value) || 0,
            },
            plastic: {
                PET: parseFloat(document.getElementById('revenue-plastic-pet').value) || 0,
                HDPEColored: parseFloat(document.getElementById('revenue-plastic-hdpe-colored').value) || 0,
                HDPENatural: parseFloat(document.getElementById('revenue-plastic-hdpe-natural').value) || 0,
            }
        },
        revenue: 0,
        buyer: document.getElementById('buyer').value || ''
    };
    
    await addData('recycle-revenue', data);
    document.getElementById('revenue-form').reset();
});

document.getElementById('landfill-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = {
        landfillDate: document.getElementById('landfill-date').value,
        weight: document.getElementById('landfill-weight').value,
        expense: document.getElementById('landfill-expense').value,
        landfillHauler: document.getElementById('landfill-hauler').value,
    };
    await addData('landfill-expense', data);
    document.getElementById('landfill-form').reset();
});


function openEditModal(type, id, entry) {
    const modal = document.getElementById('edit-modal');
    const title = document.getElementById('modal-title');
    const fieldsContainer = document.getElementById('edit-fields');
    fieldsContainer.innerHTML = ''; // Clear previous fields

    title.innerText = `Edit ${type} Entry`;
    hiddenType.value = type;
    hiddenId.value = id
    console.log(type, id ,entry)

    const createFields = (obj, prefix = '') => {
        for (const key in obj) {
            if (key === '_id' || key === '__v') continue;
            const value = obj[key];
            const fieldContainer = document.createElement('div');
            const label = document.createElement('label');
            const input = document.createElement('input');

            // Handle nested objects recursively
            if (typeof value === 'object' && !Array.isArray(value) && value !== null) {
                const nestedTitle = document.createElement('h4');
                nestedTitle.innerText = `${prefix ? prefix + '.' : ''}${key}`;
                fieldsContainer.appendChild(nestedTitle);
                createFields(value, `${prefix}${key}.`);
                continue;
            }

            // Set up the label and input
            label.innerText = `${prefix}${key.charAt(0).toUpperCase() + key.slice(1)}:`;

            if (key.toLowerCase().includes('date')) {
                input.type = 'date';
                input.value = new Date(value).toISOString().split('T')[0];
            } else if (typeof value === 'number') {
                input.type = 'number';
                input.value = value;
            } else {
                input.type = 'text';
                input.value = value;
            }

            input.name = `${prefix}${key}`;
            fieldContainer.appendChild(label);
            fieldContainer.appendChild(input);
            fieldsContainer.appendChild(fieldContainer);
        }
    };

    // Generate input fields for the entry
    createFields(entry);

    // Show the modal
    modal.style.display = 'block';

    // Attach submit handler
    document.getElementById('edit-form').onsubmit = (e) => {
        e.preventDefault();
        submitEdit(type, id);
    };
}


function closeEditModal() {
    document.getElementById('edit-modal').style.display = 'none';
}

async function submitEdit(type, id) {
    const form = document.getElementById('edit-form');
    const formData = new FormData(form);
    const data = {};

    // Helper function to set nested values
    const setNestedValue = (obj, path, value) => {
        const keys = path.split('.');
        keys.reduce((acc, key, index) => {
            if (index === keys.length - 1) {
                acc[key] = isNaN(value) ? value : Number(value); // Convert to number if applicable
            } else {
                acc[key] = acc[key] || {};
            }
            return acc[key];
        }, obj);
    };

    // Process formData to reconstruct the nested structure
    formData.forEach((value, key) => {
        if (key.toLowerCase().includes('date')) {
            setNestedValue(data, key, new Date(value).toISOString());
        } else {
            setNestedValue(data, key, value);
        }
    });
    type = hiddenType.value
    id = hiddenId.value
    try {
        const response = await fetch(`${baseURL}/${type}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });

        if (response.ok) {
            closeEditModal();
            await fetchData(); // Refresh the data
        } else {
            console.error('Failed to update data.');
        }
    } catch (error) {
        console.error('Error submitting edit:', error);
    }
}





// Fetch initial data
fetchData();
