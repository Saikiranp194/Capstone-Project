document.addEventListener("DOMContentLoaded", async () => {
    const annualReportContainer = document.getElementById("displayTable");

    // Fetch the annual report HTML
    const response = await fetch('/admin/api/annual-report');
 
    const tableHtml = await response.text();
    console.log(tableHtml)
    // Inject the HTML into the container
    annualReportContainer.innerHTML = tableHtml;
});
