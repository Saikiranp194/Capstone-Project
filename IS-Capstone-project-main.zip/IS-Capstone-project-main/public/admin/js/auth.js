const admin = sessionStorage.getItem('admin')
const token = sessionStorage.getItem('token')
const id = sessionStorage.getItem('id')

if(!admin || !token || !id){
   window.location.href='index.html'
}

function logout(){
   sessionStorage.clear()
   window.location.reload(true)
}
