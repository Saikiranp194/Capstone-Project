
  
    // Update chart and data based on selected month
    async function renderRecyclablesChart() {
        const recyclableData = await fetch('/admin/api/recyclables-weight-monthly').then(res => res.json());
    
        const chartContext = document.getElementById('recyclablesChart').getContext('2d');
        let recyclablesChart;
    
        // Identify the latest month
        const latestData = recyclableData.reduce((latest, current) => {
            const latestDate = new Date(latest._id.year, latest._id.month - 1);
            const currentDate = new Date(current._id.year, current._id.month - 1);
            return currentDate > latestDate ? current : latest;
        }, recyclableData[0]);
    
        // Render chart for the latest month by default
        updateChart(latestData);
    
        // Set dropdown to the latest month
        document.getElementById('recyclablesMonthSelect').value = `${latestData._id.year}-${String(latestData._id.month).padStart(2, '0')}`;
    
        // Handle dropdown change
        document.getElementById('recyclablesMonthSelect').addEventListener('change', (event) => {
            const selectedValue = event.target.value;
            const [year, month] = selectedValue.split('-').map(Number);
    
            // Filter data for the selected month
            const filteredData = recyclableData.find(data => data._id.year === year && data._id.month === month);
            if (filteredData) {
                updateChart(filteredData);
            }
        });
    
        // Function to update the chart
        function updateChart(data) {
            // Extract categories and values dynamically
            const labels = Object.keys(data).filter(key => key !== '_id');
            const values = Object.values(data).filter(value => typeof value === 'number');
    
            // Define colors for each category
            const backgroundColors = [
                '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', 
                '#C9CBCF', '#78C850', '#E4572E', '#3B9AE1', '#FDE74C', '#71C9CE'
            ].slice(0, labels.length);
    
            // Destroy previous chart instance if it exists
            if (recyclablesChart) recyclablesChart.destroy();
    
            recyclablesChart = new Chart(chartContext, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Weight (kg)',
                        data: values,
                        backgroundColor: backgroundColors
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'top' },
                        title: { display: true, text: `Recyclables for ${data._id.month}/${data._id.year}` }
                    }
                }
            });
        }
    }

    // Fetch and render Total Weight by Waste Type - Monthly
    async function renderTotalWeightChart() {
        const weightData = await fetch('/admin/api/total-weight-monthly').then(res => res.json());
        console.log(weightData)
        const labels = weightData.landfillData.map(data => `${data._id.month}/${data._id.year}`);
        const landfillData = weightData.landfillData.map(data => data.totalWeight);
        const foodWasteData = weightData.foodWasteData.map(data => data.totalFoodWaste);
        const recyclingData = weightData.recyclingData.map(data => data.totalRecycling);

        new Chart(document.getElementById('totalWeightChart').getContext('2d'), {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    { label: 'Landfill', data: landfillData, borderColor: '#FF6384', fill: false },
                    { label: 'Food Waste', data: foodWasteData, borderColor: '#36A2EB', fill: false },
                    { label: 'Recycling', data: recyclingData, borderColor: '#4BC0C0', fill: false }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true, text: 'Total Weight by Waste Type - Monthly' }
                }
            }
        });
    }

    // Fetch and render Diversion Rate - Monthly
    async function renderDiversionRateChart() {
        const diversionData = await fetch('/admin/api/diversion-rate-monthly').then(res => res.json());
        console.log(diversionData)
        const labels = diversionData.map(data => `${data.month}/${data.year}`);
        const diversionRates = diversionData.map(data => data.diversionRate);

        new Chart(document.getElementById('diversionRateChart').getContext('2d'), {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    { label: 'Diversion Rate (%)', data: diversionRates, borderColor: '#FF9F40', fill: false }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true, text: 'Diversion Rate - Monthly' }
                },
                scales: {
                    y: { beginAtZero: true, max: 100 }  // Diversion rate as percentage
                }
            }
        });
    }

    // Fetch and render Revenue - Monthly
    async function renderRevenueChart() {
        const revenueData = await fetch('/admin/api/revenue-monthly').then(res => res.json());
        console.log(revenueData)
        const labels = revenueData.map(data => `${data._id.month}/${data._id.year}`);
        const revenue = revenueData.map(data => data.totalRevenue);

        new Chart(document.getElementById('revenueChart').getContext('2d'), {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    { label: 'Revenue ($)', data: revenue, backgroundColor: '#FF6384' }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true, text: 'Revenue - Monthly' }
                }
            }
        });
    }

    renderRecyclablesChart();
    renderTotalWeightChart();
    renderDiversionRateChart();
    renderRevenueChart();