const mongoose = require("mongoose");

const connectWithDatabase = async () => {
    try{
        const connect = await mongoose.connect("mongodb://127.0.0.1:27017/Recycle");
        console.log("Connected to:",connect.connection.name);
    } catch (err) {
        console.log("Unable to connect database due to Error :",err);
        throw new(err)
    }
}

module.exports = connectWithDatabase;