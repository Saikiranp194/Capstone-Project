const mongoose = require("mongoose")
const validator=require("validator")
const bcrypt=require("bcryptjs")
const jwt=require("jsonwebtoken")

const recycleRevenueSchema = new mongoose.Schema({
    saleDate: {
      type: Date,
      required: true,
      default: Date.now()
    },
    materialType: {
      aluminum: {
        type: Number,
        required: false,
        default: 0
      },
      cardboard: {
        type: Number,
        required: false,
        default: 0
      },
      glass: {
        type: Number,
        required: false,
        default: 0
      },
      metal: {
        cans: {
          type: Number,
          required: false,
          default: 0
        },
        scrap: {
          type: Number,
          required: false,
          default: 0
        }
      },
      paper: {
        books: {
          type: Number,
          required: false,
          default: 0
        },
        mixed: {
          type: Number,
          required: false,
          default: 0
        },
        newspaper: {
          type: Number,
          required: false,
          default: 0
        },
        white: {
          type: Number,
          required: false,
          default: 0
        }
      },
      plastic: {
        PET: {
          type: Number,
          required: false,
          default: 0
        },
        HDPEColored: {
          type: Number, 
          required: false,
          default: 0
        },
        HDPENatural: {
          type: Number,
          required: false,
          default: 0
        }
      }
    },
    revenue: {
      type: Number,
      required: false,
      default: 0
    },
    buyer: {
      type: String,
      required: false,
      default: 0
    }
  });
  
module.exports = mongoose.model('Revenue', recycleRevenueSchema);
  