const mongoose = require("mongoose")
const validator=require("validator")
const bcrypt=require("bcryptjs")
const jwt=require("jsonwebtoken")

const recyclingSchema = new mongoose.Schema({
    date: {
      type: Date,
      required: true,
      default: Date.now()
    },
    foodWaste: {
      type: Number,
      required: false
    },
    aluminum: {
      type: Number,
      required: false
    },
    cardboard: {
      type: Number,
      required: false
    },
    glass: {
      type: Number,
      required: false
    },
    metal: {
      cans: {
        type: Number,
        required: false
      },
      scrap: {
        type: Number,
        required: false
      }
    },
    paper: {
      books: {
        type: Number,
        required: false
      },
      mixed: {
        type: Number,
        required: false
      },
      newspaper: {
        type: Number,
        required: false
      },
      white: {
        type: Number,
        required: false
      }
    },
    plastic: {
      PET: {
        type: Number,
        required: false
      },
      HDPEColored: {
        type: Number,
        required: false
      },
      HDPENatural: {
        type: Number,
        required: false
      }
    }
  });
  
  module.exports = mongoose.model('Collection', recyclingSchema);
  