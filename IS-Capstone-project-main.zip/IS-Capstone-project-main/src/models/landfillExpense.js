const mongoose = require("mongoose")
const validator=require("validator")
const bcrypt=require("bcryptjs")
const jwt=require("jsonwebtoken")


const landfillSchema = new mongoose.Schema({
    landfillDate: {
        type: Date,
        required: true
    },
    weight: {
        type: Number, // weight in lbs.
        required: false
    },
    expense: {
        type: Number, // amount in US$
        required: false
    },
    landfillHauler: {
        type: String, // name of company
        required: false
    }
});

module.exports = mongoose.model('Landfill', landfillSchema);
