const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/users.js'); 
const RecycleCollection = require('../models/recycleCollection.js');
const RecycleRevenue = require('../models/recycleRevenue.js');
const LandfillExpense = require('../models/landfillExpense.js');
const router = express.Router();
const JWT_SECRET = 'recycleprojectsceret';

// Register route
router.post('/register', async (req, res) => {
    const { username, email, password } = req.body;

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({success: false, message: 'User already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = new User({
            username,
            email,
            password: hashedPassword
        });

        await user.save();
        res.status(201).json({ success: true, message: 'User registered successfully' });
    } catch (error) {
        console.log(error)
        res.status(500).json({success: false, message: 'Server error' });
    }
});

// Login route
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ success: false, message: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ success: false, message: 'Invalid email or password' });
        }

        const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '1h' });
        res.json({ success: true, token, user });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Reset Password route
router.post('/reset-password', async (req, res) => {
    const { email, newPassword } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ success: false, message: 'User not found' });
        }
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        user.password = hashedPassword;
        await user.save();

        res.json({success: true, message: 'Password reset successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Get all recycle collection data
router.get('/recycle-collection', async (req, res) => {
    try {
        const data = await RecycleCollection.find().sort({ date: -1 });
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Add new recycle collection data
router.post('/recycle-collection', async (req, res) => {
    const data = new RecycleCollection(req.body);
    try {
        const savedData = await data.save();
        res.status(201).json(savedData);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});


// Get all recycle revenue data
router.get('/recycle-revenue', async (req, res) => {
    try {
        const data = await RecycleRevenue.find().sort({ saleDate: -1 });
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Add new recycle revenue data
router.post('/recycle-revenue', async (req, res) => {
    const data = new RecycleRevenue(req.body);
    try {
        const savedData = await data.save();
        res.status(201).json(savedData);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});




// Get all landfill expense data
router.get('/landfill-expense', async (req, res) => {
    try {
        const data = await LandfillExpense.find().sort({ landfillDate: -1 });
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Add new landfill expense data
router.post('/landfill-expense', async (req, res) => {
    const data = new LandfillExpense(req.body);
    console.log(data)
    try {
        const savedData = await data.save();
        res.status(201).json(savedData);
    } catch (error) {
        console.log(error)
        res.status(400).json({ message: error.message });
    }
});



module.exports = router;
