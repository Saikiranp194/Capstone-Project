const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Admin = require('../models/admin.js');
const User = require('../models/users.js');
const RecycleCollection = require('../models/recycleCollection.js');
const RecycleRevenue = require('../models/recycleRevenue.js');
const LandfillExpense = require('../models/landfillExpense.js');
const { contentSecurityPolicy } = require('helmet');
const router = express.Router();

const JWT_SECRET = 'your_jwt_secret_key';

// Register route
router.post('/register', async (req, res) => {
    const { username, email, password } = req.body;

    try {
        const existingAdmin = await Admin.findOne({ email });
        if (existingAdmin) {
            return res.status(400).json({success: false, message: 'Admin already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const admin = new Admin({
            username,
            email,
            password: hashedPassword
        });

        await admin.save();
        res.status(201).json({success: true, message: 'Admin registered successfully' });
    } catch (error) {
        res.status(500).json({success: false, message: 'Server error' });
    }
});

// Login route
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const admin = await Admin.findOne({ email });
        if (!admin) {
            return res.status(400).json({success: false, message: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(400).json({success: false, message: 'Invalid email or password' });
        }

        const token = jwt.sign({ id: admin._id }, JWT_SECRET, { expiresIn: '1h' });
        res.status(200).json({success: true, token, admin });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Reset Password route
router.post('/reset-password', async (req, res) => {
    const { email, newPassword } = req.body;

    try {
        const admin = await Admin.findOne({ email });
        if (!admin) {
            return res.status(400).json({ message: 'Admin not found' });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);

        admin.password = hashedPassword;
        await admin.save();

        res.json({ message: 'Password reset successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// GET /getUsers - Fetch all users
router.get('/getUsers', async (req, res) => {
    try {
        const users = await User.find();
        res.json({success: true,users});
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
});

// GET /getUsers - Fetch all users
router.get('/getAdmins', async (req, res) => {
    try {
        const users = await Admin.find();
        res.json({success: true,users});
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
});

// POST /addUser - Add a new user
router.post('/addUser', async (req, res) => {
    const { username, email } = req.body;

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const newUser = new User({
            username,
            email
        });

        await newUser.save();
        res.status(201).json({ message: 'User added successfully' });
    } catch (err) {
        console.log(err)
        res.status(500).json({ message: 'Server error' });
    }
});


// PUT /editUser/:id - Edit a user
router.put('/editUser/:id', async (req, res) => {
    const { username, email } = req.body;
    const userId = req.params.id;

    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        user.username = username || user.username;
        user.email = email || user.email;

        await user.save();
        res.json({ message: 'User updated successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
});


// DELETE /deleteUser/:id - Delete a user
router.delete('/deleteUser/:id', async (req, res) => {
    const userId = req.params.id;
    
    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        await user.deleteOne({_id:userId});
        res.json({ message: 'User deleted successfully' });
    } catch (err) {
        console.log(err)
        res.status(500).json({ message: 'Server error' });
    }
});


// PUT /editUser/:id - Edit a user
router.put('/editAdmin/:id', async (req, res) => {
    const { username, email } = req.body;
    const userId = req.params.id;

    try {
        const user = await Admin.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'Admin not found' });
        }

        user.username = username || user.username;
        user.email = email || user.email;

        await user.save();
        res.json({ message: 'Admin updated successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
});


// DELETE /deleteUser/:id - Delete a user
router.delete('/deleteAdmin/:id', async (req, res) => {
    const userId = req.params.id;
    
    try {
        const user = await Admin.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'Admin not found' });
        }

        await user.deleteOne({_id:userId});
        res.json({ message: 'Admin deleted successfully' });
    } catch (err) {
        console.log(err)
        res.status(500).json({ message: 'Server error' });
    }
});



// Get all recycle collection data
router.get('/recycle-collection', async (req, res) => {
    try {
        const data = await RecycleCollection.find().sort({ date: -1 });
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Add new recycle collection data
router.post('/recycle-collection', async (req, res) => {
    const data = new RecycleCollection(req.body);
    try {
        const savedData = await data.save();
        res.status(201).json(savedData);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Edit recycle collection data
router.put('/recycle-collection/:id', async (req, res) => {
    try {
        const updatedData = await RecycleCollection.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedData) return res.status(404).send('Data not found');
        res.json(updatedData);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Delete recycle collection data
router.delete('/recycle-collection/:id', async (req, res) => {
    try {
        const deletedData = await RecycleCollection.findByIdAndDelete(req.params.id);
        if (!deletedData) return res.status(404).send('Data not found');
        res.json({ message: 'Data deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get all recycle revenue
router.get('/recycle-revenue', async (req, res) => {
    try {
        const data = await RecycleRevenue.find().sort({ saleDate: -1 });
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Add new recycle revenue data
router.post('/recycle-revenue', async (req, res) => {
    const data = new RecycleRevenue(req.body);
    try {
        const savedData = await data.save();
        res.status(201).json(savedData);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Edit recycle revenue data
router.put('/recycle-revenue/:id', async (req, res) => {
    try {
        const updatedData = await RecycleRevenue.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedData) return res.status(404).send('Data not found');
        res.json(updatedData);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Delete recycle revenue data
router.delete('/recycle-revenue/:id', async (req, res) => {
    try {
        console.log(req.params)
        const deletedData = await RecycleRevenue.findByIdAndDelete(req.params.id);
        console.log(deletedData)
        if (!deletedData) return res.status(404).send('Data not found');
        res.json({ message: 'Data deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get all landfill expense data
router.get('/landfill-expense', async (req, res) => {
    try {
        const data = await LandfillExpense.find().sort({ landfillDate: -1 });
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Add new landfill expense data
router.post('/landfill-expense', async (req, res) => {
    const data = new LandfillExpense(req.body);
   // console.log(body)
    try {
        const savedData = await data.save();
        res.status(201).json(savedData);
    } catch (error) {
        console.log(error)
        res.status(400).json({ message: error.message });
    }
});

// Edit landfill expense data
router.put('/landfill-expense/:id', async (req, res) => {
    try {
        const updatedData = await LandfillExpense.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedData) return res.status(404).send('Data not found');
        res.json(updatedData);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Delete landfill expense data
router.delete('/landfill-expense/:id', async (req, res) => {
    try {
        const deletedData = await LandfillExpense.findByIdAndDelete(req.params.id);
        if (!deletedData) return res.status(404).send('Data not found');
        res.json({ message: 'Data deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


router.get('/waste-by-type', async (req, res) => {
    try {
        const collectionData = await RecycleCollection.aggregate([
            {
                $group: {
                    _id: null,
                    aluminum: { $sum: "$aluminum" },
                    cardboard: { $sum: "$cardboard" },
                    glass: { $sum: "$glass" },
                    cans: { $sum: "$metal.cans" },
                    scrap: { $sum: "$metal.scrap" },
                    books: { $sum: "$paper.books" },
                    mixedPaper: { $sum: "$paper.mixed" },
                    newspaper: { $sum: "$paper.newspaper" },
                    whitePaper: { $sum: "$paper.white" },
                    PET: { $sum: "$plastic.PET" },
                    HDPEColored: { $sum: "$plastic.HDPEColored" },
                    HDPENatural: { $sum: "$plastic.HDPENatural" }
                }
            }
        ]);

        res.json(collectionData[0]);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


router.get('/landfill', async (req, res) => {
    try {
        const landfillData = await LandfillExpense.aggregate([
            {
                $group: {
                    _id: null,
                    totalWeight: { $sum: "$weight" }
                }
            }
        ]);

        res.json(landfillData[0]);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.get('/food-waste', async (req, res) => {
    try {
        const foodWasteData = await RecycleCollection.aggregate([
            {
                $group: {
                    _id: null,
                    totalFoodWaste: { $sum: "$foodWaste" }
                }
            }
        ]);

        res.json(foodWasteData[0]);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.get('/recyclables-weight-monthly', async (req, res) => {
    try {
        const recyclableData = await RecycleCollection.aggregate([
            {
                $group: {
                    _id: { month: { $month: "$date" }, year: { $year: "$date" } },
                    aluminum: { $sum: "$aluminum" },
                    cardboard: { $sum: "$cardboard" },
                    glass: { $sum: "$glass" },
                    metalCans: { $sum: "$metal.cans" },
                    metalScrap: { $sum: "$metal.scrap" },
                    paperBooks: { $sum: "$paper.books" },
                    paperMixed: { $sum: "$paper.mixed" },
                    paperNewspaper: { $sum: "$paper.newspaper" },
                    paperWhite: { $sum: "$paper.white" },
                    plasticPET: { $sum: "$plastic.PET" },
                    plasticHDPEColored: { $sum: "$plastic.HDPEColored" },
                    plasticHDPENatural: { $sum: "$plastic.HDPENatural" }
                }
            },
            { $sort: { "_id.year": 1, "_id.month": 1 } }
        ]);
        
        res.json(recyclableData);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


router.get('/total-weight-monthly', async (req, res) => {
    try {
        const landfillData = await LandfillExpense.aggregate([
            { $group: { _id: { month: { $month: "$landfillDate" }, year: { $year: "$landfillDate" } }, totalWeight: { $sum: "$weight" } } },
            { $sort: { "_id.year": 1, "_id.month": 1 } }
        ]);

        const foodWasteData = await RecycleCollection.aggregate([
            { $group: { _id: { month: { $month: "$date" }, year: { $year: "$date" } }, totalFoodWaste: { $sum: "$foodWaste" } } },
            { $sort: { "_id.year": 1, "_id.month": 1 } }
        ]);

        const recyclingData = await RecycleCollection.aggregate([
            { $group: { _id: { month: { $month: "$date" }, year: { $year: "$date" } }, totalRecycling: { $sum: { $add: ["$aluminum", "$cardboard", "$glass", "$metal.cans", "$metal.scrap", "$paper.books", "$paper.mixed", "$paper.newspaper", "$paper.white", "$plastic.PET", "$plastic.HDPEColored", "$plastic.HDPENatural"] } } } },
            { $sort: { "_id.year": 1, "_id.month": 1 } }
        ]);

        res.json({ landfillData, foodWasteData, recyclingData });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.get('/diversion-rate-monthly', async (req, res) => {
    try {
        const totalWasteData = await RecycleCollection.aggregate([
            { $group: { _id: { month: { $month: "$date" }, year: { $year: "$date" } }, totalRecycling: { $sum: { $add: ["$aluminum", "$cardboard", "$glass", "$metal.cans", "$metal.scrap", "$paper.books", "$paper.mixed", "$paper.newspaper", "$paper.white", "$plastic.PET", "$plastic.HDPEColored", "$plastic.HDPENatural"] } }, totalFoodWaste: { $sum: "$foodWaste" } } },
            { $sort: { "_id.year": 1, "_id.month": 1 } }
        ]);

        const landfillData = await LandfillExpense.aggregate([
            { $group: { _id: { month: { $month: "$landfillDate" }, year: { $year: "$landfillDate" } }, totalLandfill: { $sum: "$weight" } } },
            { $sort: { "_id.year": 1, "_id.month": 1 } }
        ]);

        const diversionRate = totalWasteData.map((data, index) => {
            const monthData = landfillData.find(ld => ld._id.month === data._id.month && ld._id.year === data._id.year);
            const landfillWeight = monthData ? monthData.totalLandfill : 0;
            const totalDiverted = data.totalRecycling + data.totalFoodWaste;
            const diversionRate = totalDiverted / (totalDiverted + landfillWeight) * 100;

            return { month: data._id.month, year: data._id.year, diversionRate: diversionRate.toFixed(2) };
        });

        res.json(diversionRate);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.get('/revenue-monthly', async (req, res) => {
    try {
        const revenueData = await RecycleRevenue.aggregate([
            { $group: { _id: { month: { $month: "$saleDate" }, year: { $year: "$saleDate" } }, totalRevenue: { $sum: "$revenue" } } },
            { $sort: { "_id.year": 1, "_id.month": 1 } }
        ]);

        res.json(revenueData);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


// Get monthly revenue
router.get('/monthly-revenue', async (req, res) => {
    try {
        const data = await RecycleRevenue.aggregate([
            {
                $group: {
                    _id: { $month: "$saleDate" },
                    totalRevenue: { $sum: "$revenue" }
                }
            },
            { $sort: { "_id": 1 } }
        ]);
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get monthly recycle collection weights
router.get('/monthly-recycle-collection', async (req, res) => {
    try {
        const data = await RecycleCollection.aggregate([
            {
                $project: {
                    month: { $month: "$date" },
                    foodWaste: 1,
                    aluminum: 1,
                    cardboard: 1,
                    glass: 1,
                    "metal.cans": 1,
                    "metal.scrap": 1,
                    "paper.books": 1,
                    "paper.mixed": 1,
                    "paper.newspaper": 1,
                    "paper.white": 1,
                    "plastic.PET": 1,
                    "plastic.HDPEColored": 1,
                    "plastic.HDPENatural": 1
                }
            },
            {
                $group: {
                    _id: "$month",
                    totalFoodWaste: { $sum: "$foodWaste" },
                    totalAluminum: { $sum: "$aluminum" },
                    totalCardboard: { $sum: "$cardboard" },
                    totalGlass: { $sum: "$glass" },
                    totalMetal: { $sum: { $add: ["$metal.cans", "$metal.scrap"] } },
                    totalPaper: { $sum: { $add: ["$paper.books", "$paper.mixed", "$paper.newspaper", "$paper.white"] } },
                    totalPlastic: { $sum: { $add: ["$plastic.PET", "$plastic.HDPEColored", "$plastic.HDPENatural"] } }
                }
            },
            { $sort: { "_id": 1 } }
        ]);
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get monthly landfill data
router.get('/monthly-landfill', async (req, res) => {
    try {
        const data = await LandfillExpense.aggregate([
            {
                $group: {
                    _id: { $month: "$landfillDate" },
                    totalLandfillWeight: { $sum: "$weight" },
                    totalLandfillExpense: { $sum: "$expense" }
                }
            },
            { $sort: { "_id": 1 } }
        ]);
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});



// Annual Report Function 
router.get('/annual-report', async (req, res) => {
    try {
        // Fetch data from database in parallel
        const [revenueData, collectionData, landfillData] = await Promise.all([
            RecycleRevenue.find().sort({ "saleDate": 1 }),
            RecycleCollection.find().sort({ "date": 1 }),
            LandfillExpense.find().sort({ "landfillDate": 1 })
        ]);

        const months = [
            "Nov-23", "Dec-23", "Jan-24", "Feb-24", "Mar-24", "Apr-24", "May-24", "Jun-24",
            "Jul-24", "Aug-24", "Sep-24", "Oct-24"
        ];

        // Initialize report structure
        let ytdReport = {
            recyclingRevenue: new Array(12).fill(0),
            landfillLbs: new Array(12).fill(0),
            compostLbs: new Array(12).fill(0),
            cardboardLbs: new Array(12).fill(0),
            paperLbs: new Array(12).fill(0),
            plasticLbs: new Array(12).fill(0),
            aluminumLbs: new Array(12).fill(0),
            metalCansLbs: new Array(12).fill(0),
            metalScrapLbs: new Array(12).fill(0),
            glassLbs: new Array(12).fill(0),
            totalRecycledLbs: new Array(12).fill(0),
            totalWasteGeneratedLbs: new Array(12).fill(0),
            totalWasteDivertedLbs: new Array(12).fill(0),
            wasteDiversionRate: new Array(12).fill(0)
        };

        // Map data into report structure
        const mapToMonths = (data, type) => {
            data.forEach(item => {
                const date = new Date(item.saleDate || item.date || item.landfillDate);
                const monthIndex = (date.getMonth() + 2) % 12; // Shift for FY alignment
                if (monthIndex < 0 || monthIndex >= 12) return;

                if (type === 'revenue') {
                    ytdReport.recyclingRevenue[monthIndex] += item.revenue || 0;
                } else if (type === 'collection') {
                    const {
                        foodWaste = 0, aluminum = 0, cardboard = 0,
                        glass = 0, metal = {}, paper = {}, plastic = {}
                    } = item;

                    const paperLbs =
                        (paper.books || 0) +
                        (paper.mixed || 0) +
                        (paper.newspaper || 0) +
                        (paper.white || 0);

                    const plasticLbs =
                        (plastic.PET || 0) +
                        (plastic.HDPEColored || 0) +
                        (plastic.HDPENatural || 0);

                    const metalLbs =
                        (metal.cans || 0) +
                        (metal.scrap || 0);

                    const recycledLbs = aluminum + cardboard + glass + paperLbs + plasticLbs + metalLbs;
                    const wasteGenerated = recycledLbs + foodWaste + (item.weight || 0);

                    ytdReport.totalRecycledLbs[monthIndex] += recycledLbs;
                    ytdReport.compostLbs[monthIndex] += foodWaste;
                    ytdReport.cardboardLbs[monthIndex] += cardboard;
                    ytdReport.paperLbs[monthIndex] += paperLbs;
                    ytdReport.plasticLbs[monthIndex] += plasticLbs;
                    ytdReport.aluminumLbs[monthIndex] += aluminum;
                    ytdReport.metalCansLbs[monthIndex] += metal.cans || 0;
                    ytdReport.metalScrapLbs[monthIndex] += metal.scrap || 0;
                    ytdReport.glassLbs[monthIndex] += glass;

                    ytdReport.totalWasteGeneratedLbs[monthIndex] += wasteGenerated;
                    ytdReport.totalWasteDivertedLbs[monthIndex] += recycledLbs + foodWaste;
                } else if (type === 'landfill') {
                    ytdReport.landfillLbs[monthIndex] += item.weight || 0;
                    ytdReport.totalWasteGeneratedLbs[monthIndex] += item.weight || 0;
                }
            });
        };

        // Apply data mapping
        mapToMonths(revenueData, 'revenue');
        mapToMonths(collectionData, 'collection');
        mapToMonths(landfillData, 'landfill');

        // Calculate totals and diversion rate
        let totalWasteGeneratedForYear = 0;
        let totalWasteDivertedForYear = 0;

        for (let i = 0; i < 12; i++) {
            const totalWasteGenerated = ytdReport.totalWasteGeneratedLbs[i];
            const totalWasteDiverted = ytdReport.totalWasteDivertedLbs[i];
            totalWasteGeneratedForYear += totalWasteGenerated;
            totalWasteDivertedForYear += totalWasteDiverted;

            if (totalWasteGenerated > 0) {
                ytdReport.wasteDiversionRate[i] = ((totalWasteDiverted / totalWasteGenerated) * 100).toFixed(2);
            }
        }
        let tableHtml = `
                        <table>
                            <tr>
                                <th>FY24</th>
                                ${months.map(month => `<th>${month}</th>`).join('')}
                                <th>Total</th>
                            </tr>
            `;

            const rows = [
                { label: 'Recycling Revenue ($)', data: ytdReport.recyclingRevenue },
                { label: 'Landfill lbs.', data: ytdReport.landfillLbs },
                { label: 'Compost lbs.', data: ytdReport.compostLbs },
                { label: 'Cardboard lbs.', data: ytdReport.cardboardLbs },
                { label: 'Paper lbs.', data: ytdReport.paperLbs },
                { label: 'Plastic lbs.', data: ytdReport.plasticLbs },
                { label: 'Aluminum lbs.', data: ytdReport.aluminumLbs },
                { label: 'Metal (Cans) lbs.', data: ytdReport.metalCansLbs },
                { label: 'Metal (Scrap) lbs.', data: ytdReport.metalScrapLbs },
                { label: 'Glass lbs.', data: ytdReport.glassLbs },
                { label: 'Total Recycled lbs.', data: ytdReport.totalRecycledLbs },
                { label: 'Total Waste Generated lbs.', data: ytdReport.totalWasteGeneratedLbs },
                { label: 'Total Waste Diverted lbs.', data: ytdReport.totalWasteDivertedLbs },
                { label: 'Waste Diversion Rate (%)', data: ytdReport.wasteDiversionRate }, // Last row
            ];

            rows.forEach((row, index) => {
                const total =
                    index === rows.length - 1 
                        ? (
                            rows[11].data.reduce((sum, _, i) => {
                                const totalWasteGenerated = parseFloat(rows[11].data[i] || 0); 
                                const totalWasteDiverted = parseFloat(rows[12].data[i] || 0); 
                                return totalWasteGenerated > 0
                                    ? sum + (totalWasteDiverted / totalWasteGenerated) * 100
                                    : sum;
                            }, 0) / months.length 
                        ).toFixed(2)
                        : row.data.reduce((sum, value) => sum + parseFloat(value || 0), 0).toFixed(2); // Calculate totals for other rows

                tableHtml += `<tr><td>${row.label}</td>${row.data.map(value => `<td>${value}</td>`).join('')}<td>${total}</td></tr>`;
            });

            tableHtml += `
                        </table>
            `;

            res.send(tableHtml);


        
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});









module.exports = router;
