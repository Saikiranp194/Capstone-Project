const express = require('express')
const port = 8080
const server = express()
const cors = require('cors')
const helmet = require('helmet')
const path=require('path')
const publicPath=path.join(__dirname,'../public');
const connectWithDatabase = require("./db/mongoConnect.js");
const Routers = require('./routers/userRoute.js');
const AdminRouters = require('./routers/adminRoute.js');
console.log(publicPath)
server.use(express.static(publicPath));
server.use(express.urlencoded({ extended: true }));
server.use(express.json())

// Test API
server.get('/test', (req,res) => {
    res.send("Server is running...");
})

server.use('/api', Routers);
server.use('/admin/api', AdminRouters);
server.use(cors());
server.use(
	helmet({
	  contentSecurityPolicy: false,
	  xDownloadOptions: false,
	  XContentTypeOptions: false
	})
  );



connectWithDatabase().then(() => {
    try {
		server.listen(port, () => {
			console.log(`Server started at http://localhost:${port}`);
		});
	} catch (err) {
		console.log("Unable to connect to the database due to: ", err);
    }
});